const mongoose = require("mongoose");
var moment = require("moment"); // modülü çağır
var now = moment(); // şu anki tarih ve saati al

var postSchema = mongoose.Schema({
  name: String,
  image: String,
  description: String,
  date: String,
  author: {
    id: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
    },
    username: String,
  },
  comments: [
    {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Comment",
    },
  ],
});

module.exports = mongoose.model("Post", postSchema);
