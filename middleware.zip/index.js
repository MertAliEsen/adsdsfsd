const Discord = require("discord.js");
const { messageReaction, user, MessageEmbed } = require("discord.js");
const client = new Discord.Client();
const chalk = require("chalk");
const disbut = require("discord-buttons");
const discord = require("discord.js");
const config = require("./cfg/config.json");
const fs = require("fs");
disbut(client);
const Enmap = require("enmap");
var request = require("request");
const moment = require("moment");
const db = require("quick.db");
client.commands = new Enmap();
client.config = config;
const ayarlar = require("./ayarlar.json");
const jsonfile = require("jsonfile");
const file = "./cfg/config.json";
const file2 = "./cfg/config2.json";

var multer  = require('multer');
var updateJson = require('update-json');
const json = require("json-update");
const dateformat = require("dateformat");

const express = require("express");
var router = express.Router();

const http = require("http");
const app = express();

const bodyParser= require('body-parser');

app.use(bodyParser.urlencoded({extended: true}))

var uploadRouter = require('./upload');
app.use('/', uploadRouter);

const dotenv = require("dotenv").config();
const mongoose = require("mongoose");
const passport = require("passport");
const LocalStrategy = require("passport-local");
const methodOverride = require("method-override");
const User = require("./models/user");

//---------DATABASE SETUP------------------
const mongo_uri = process.env.mongo_uri;

const connect = mongoose.connect(mongo_uri, {
  useUnifiedTopology: true,
  useNewUrlParser: true,
});
connect.then(
  (db) => {
    console.log("Veri merkezine bağlandı");
  },
  (err) => {
    console.log("Veri merkezinde Hata ", err);
  }
);
// --------------------------------------

//-------------GENRAL CONFIGURATION----------
app.use(bodyParser.urlencoded({ extended: true }));
app.set("view engine", "hbs");
app.use(express.static(__dirname + "/public"));
app.use(methodOverride("_method"));
//-------------------------------------------

//------------ROUTERS------------------------
const commentRoutes = require("./routes/comments");
const postRoutes = require("./routes/posts");
const indexRoutes = require("./routes/index");
const userRoutes = require("./routes/user");
//---------------------------------------------

//------------PASSPORT CONFIGURATION-----------
app.use(
  require("express-session")({
    secret: "I am the best",
    resave: false,
    saveUninitialized: false,
  })
);
app.use(passport.initialize());
app.use(passport.session());
passport.use(new LocalStrategy(User.authenticate()));
passport.serializeUser(User.serializeUser());
passport.deserializeUser(User.deserializeUser());

//to get current logged in user
app.use((req, res, next) => {
  res.locals.currentUser = req.user;
  next();
});
//------------------------------------------------

app.use("/", indexRoutes);
app.use("/posts", postRoutes);
app.use("/posts/:id/comments", commentRoutes);
app.use("/user", userRoutes);

let port = process.env.PORT || 3030;

app.listen(port, () => {
  console.log(`Server Listening at http://localhost:${port}`);
});






client.on("ready", () => {
  console.log(
    chalk.blue(
      `${client.user.username} is ready. (${client.guilds.cache.size} Guilds) | Prefix: ${ayarlar.prefix}`
    )
  );

  client.user.setPresence({
    activity: { type: "PLAYING", name: `Mert` },
    status: "idle",
  });
});

fs.readdir("./events/", (err, files) => {
  if (err) return console.error(err);
  files.forEach((file) => {
    const event = require(`./events/${file}`);
    let eventName = file.split(".")[0];
    client.on(eventName, event.bind(null, client));
  });
});

client.commands = new Enmap();
fs.readdir("./commands/", (err, files) => {
  if (err) return console.error(err);
  console.log(chalk.magenta("Loading Commands..."));
  files.forEach((file) => {
    if (!file.endsWith(".js")) return;
    let props = require(`./commands/${file}`);
    let commandName = file.split(".")[0];
    console.log(chalk.green(`[+] ${commandName}`));
    client.commands.set(commandName, props);
  });
});

client.login("ODMwNDcyMTg1OTY5Mzc3MzMw.GdVmJS.To8mQ8bescY_1I8fPz8OhWpKY9exw6j8DltxeM");











client.on('message', message => {






if(message.channel.id == ayarlar.logokanal) {
  if(message.author.bot) return;
  var takımisim = message.content
if (takımisim.length < 1) {
  message.delete({timeout: 5000})
 message.channel.send(':warning: Bir takım ismi girin').then(aa => {
                aa.delete({timeout: 6000})
 })} else {
 try{
var takımlogo = message.attachments.first().url
    var name2 = takımisim.toUpperCase();
db.set(name2,takımlogo)

       
       
         json.update("./logolar/"+ name2 +".json", {
       
          Q : takımlogo
         })
       
       
         message.react(ayarlar.emoji)

         console.log(name2)
         console.log(takımlogo)
 }  catch(err) {
   message.delete() //{timeout: 5000})
   message.channel.send(':warning: Bir görsel ekleyiniz!').then(aa => {
              aa.delete({timeout: 6000})
    })
   
  }
  }}
})

















client.on('message', message => {

  
if(message.channel.id == ayarlar.slotkanal) {
  if(message.author.bot) return;
  const choice = message.content.split("\n")
  console.log(choice)
  
  let staki1 = choice[0] || ''
let staki2 = choice[1] || ''
let staki3 = choice[2] || ''
let staki4 = choice[3] || ''
let staki5 = choice[4] || ''
let staki6 = choice[5] || ''
let staki7 = choice[6] || ''
let staki8 = choice[7] || ''
let staki9 = choice[8] || ''
let staki10 = choice[9] || ''
let staki11 = choice[10] || ''
let staki12 = choice[11] || ''
let staki13 = choice[12] || ''
let staki14 = choice[13] || ''
let staki15 = choice[14] || ''
let staki16 = choice[15] || ''
let staki17 = choice[16] || ''
let staki18 = choice[17] || ''
if (staki1.length < 1) {
  message.delete({timeout: 5000})
 message.channel.send(':warning: Bir takım ismi girin').then(aa => {
                aa.delete({timeout: 6000})
 })} else {

if (staki1!= null) {   var taki1 = staki1.toUpperCase(); } else {var taki1 = null}
if (staki2!= null) {   var taki2 = staki2.toUpperCase(); } else {var taki2 = null}
if (staki3!= null) {   var taki3 = staki3.toUpperCase(); } else {var taki3 = null}
if (staki4!= null) {   var taki4 = staki4.toUpperCase(); } else {var taki4 = null}
if (staki5!= null) {   var taki5 = staki5.toUpperCase(); } else {var taki5 = null}
if (staki6!= null) {   var taki6 = staki6.toUpperCase(); } else {var taki6 = null}
if (staki7!= null) {   var taki7 = staki7.toUpperCase(); } else {var taki7 = null}
if (staki8!= null) {   var taki8 = staki8.toUpperCase(); } else {var taki8 = null}
if (staki9!= null) {   var taki9 = staki9.toUpperCase(); } else {var taki9 = null}
if (staki10!= null) {   var taki10 = staki10.toUpperCase(); } else {var taki10 = null}
if (staki11!= null) {   var taki11 = staki11.toUpperCase(); } else {var taki11 = null}
if (staki12!= null) {   var taki12 = staki12.toUpperCase(); } else {var taki12 = null}
if (staki13!= null) {   var taki13 = staki13.toUpperCase(); } else {var taki13 = null}
if (staki14!= null) {   var taki14 = staki14.toUpperCase(); } else {var taki14 = null}
if (staki15!= null) {   var taki15 = staki15.toUpperCase(); } else {var taki15 = null}
if (staki16!= null) {   var taki16 = staki16.toUpperCase(); } else {var taki16 = null}
if (staki17!= null) {   var taki17 = staki17.toUpperCase(); } else {var taki17 = null}
if (staki18!= null) {   var taki18 = staki18.toUpperCase(); } else {var taki18 = null}
db.set("staki1", `${taki1}`)
db.set("staki2", `${taki2}`)
db.set("staki3", `${taki3}`)
db.set("staki4", `${taki4}`)
db.set("staki5", `${taki5}`)
db.set("staki6", `${taki6}`)
db.set("staki7", `${taki7}`)
db.set("staki8", `${taki8}`)
db.set("staki9", `${taki9}`)
db.set("staki10", `${taki10}`)
db.set("staki11", `${taki11}`)
db.set("staki12", `${taki12}`)
db.set("staki13", `${taki13}`)
db.set("staki14", `${taki14}`)
db.set("staki15", `${taki15}`)
db.set("staki16", `${taki16}`)
db.set("staki17", `${taki17}`)
db.set("staki18", `${taki18}`)


         message.react("<a:tik_3:1246143810728230934>")









      
  
  
    }}
})
















client.on('message', message => {

  
  if(message.channel.id == ayarlar.takımkayıtkanal) {
    if(message.author.bot) return;
    const choice = message.content.split("\n")
    
    
            let takımkaptanı = message.mentions.users.first()
  
  let takımadı = choice[0] 
  //let takımkaptanı = choice[1] 
         let kayıt = message.guild.member(message.author)
    if (db.get(`${kayıt}_takım`, `var`)) {
    message.delete({timeout: 5000})
   message.channel.send(':warning: Zaten bir takımınız var').then(aa => {
                  aa.delete({timeout: 6000})
   })} else{
  if (takımadı.length < 1) {
    message.delete({timeout: 5000}) 
   message.channel.send(':warning: Bir takım ismi girin').then(aa => {
                  aa.delete({timeout: 6000})
   })} else{
  
     if (!takımkaptanı) {
    message.delete({timeout: 5000})
   message.channel.send(':warning: Bir takım kaptanı etiketleyin').then(aa => {
                  aa.delete({timeout: 6000})
   })} else{
     
  
      var name2 = takımadı.toUpperCase();
  message.channel.send("**Takım kaydedildi**")
       message.guild.roles.create({data:{name: `${name2}`, color: "#66ff00", permissions: 0}, reason: 'Takım'});
  var roll = message.guild.roles.cache.find(r => r.name === name2);    
    
    
    client.on('roleCreate', async (role) => {   
      //message.author.roles.add(roll.id)
  
  const channel = role.guild.channels.cache.get(ayarlar.takımkayıtlogkanal)
      let embed = new Discord.MessageEmbed()
  .addField(`Takım kayıt edildi`, ` Takım ismi: \`${name2}\`\n Rol: <@&${role.id}>`)
  .addField(`Takım kayıt edildi`, ` Takım Kaptanı: ${takımkaptanı}`)
  .addField(`Kayıt eden kullanıcı:`,`${message.author}`)
      .setColor(ayarlar.renk)
      .setFooter(`${role.client.user.username}`, role.client.user.avatarURL())
     kayıt.roles.add(role)
    kayıt.setNickname(`${name2} | ${message.author.username}`)
     db.set(`${kayıt}_takım`, "var")
  message.channel.send(embed)
  //    db.set(`${kayıt}_takım`, "var")
    
  });
  
           message.react(ayarlar.emoji)
      
   }
   }}
  }})
  
  



