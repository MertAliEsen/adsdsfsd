const Discord = require("discord.js");
const Canvas = require("canvas"),
  client = new Discord.Client();
const jsonfile = require('jsonfile')
const file2 = './cfg/config2.json'
const db = require('quick.db')
const { registerFont, createCanvas } = require('canvas')
registerFont("American Captain.ttf", { family: "sans-serif" });



module.exports.run = async (client, message, args) => {              

  const canvas = Canvas.createCanvas(512, 256);
  const ctx = canvas.getContext("2d");
 
 

  ctx.fillStyle = "#fff";
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.font = "32px 'sans-serif'";
   // TAKIMLAR // 
  ctx.fillText(`takımörnek`, 256, 120);
  const attachment = new Discord.MessageAttachment(canvas.toBuffer(), "");
  message.channel.send(attachment);
 
 

};

exports.conf = { 
  enabled: true,
  guildOnly: false,
  aliases: ["canvas"]
};

exports.help = {
  name: "canvas"
};



