const Discord = require('discord.js')
const db = require('quick.db')
const ayarlar = require('../ayarlar.json');

exports.run = async(client, message, args) => {
  
    if(!message.member.roles.cache.has(`${ayarlar.rol}`)) return message.channel.send('Yetkin yok')

let logk = message.mentions.channels.first();
let logkanal = await db.fetch(`modlog_${message.guild.id}`)
  
if (args[0] === "kapat") {
if(!logkanal) {
  

 message.channel.send(`Mod-log Kanalı Zaten ayarlı değil`)
} else {
    
db.delete(`modlog_${message.guild.id}`)
  

 message.channel.send(`Mod-Log Kanalı başarıyla sıfırlandı.`)
}}
  


if (args[0] === "aç") {


    
if (!logk) {
  

    message.channel.send(`Bir kanal belirt`)
   }
   
   db.set(`modlog_${message.guild.id}`, logk.id)
   
   
   message.channel.send(`Mod-Log kanalı başarıyla ${logk} olarak ayarlandı.`);
}





if (!args[0]) {
    message.channel.send(`**"${ayarlar.prefix}modlog aç/kapat #kanal"** olarak kullanınız.`)
}




};

