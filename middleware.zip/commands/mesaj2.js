const Discord = require('discord.js');
const ayarlar = require('../ayarlar.json');

exports.run = async (client, message, args) => {
                        if(!message.member.roles.cache.has(`${ayarlar.rol}`)) return message.channel.send('Yetkin yok')
  
  let mesaj = args.slice(0).join(' ');
if (mesaj.length < 1) return message.reply('Lütfen bir şey yazın.');

   

const embed1 = new Discord.MessageEmbed()
.setColor(`${ayarlar.renk}`)
.setDescription(`${mesaj}`)
.setThumbnail(`${ayarlar.foto}`)
message.channel.send(embed1)
  message.delete();

};

