const Discord = require("discord.js");
const Canvas = require("canvas"),
  client = new Discord.Client();
const jsonfile = require('jsonfile')
const file2 = './cfg/config2.json'
const ayarlar = require('../ayarlar.json');
const db = require('quick.db')
const { registerFont, createCanvas } = require('canvas')
registerFont("American-Captain.otf", { family: "American-Captain" });
module.exports.run = async (client, message, args) => {
                        if(!message.member.roles.cache.has(`${ayarlar.rol}`)) return message.channel.send('Yetkin yok')

  
                
  

    

  
  const canvas = Canvas.createCanvas(1280, 720);
  const ctx = canvas.getContext("2d");
 
  db.set(' ', "https://scontent.xx.fbcdn.net/v/t1.15752-9/441436209_1858152441324408_7763326068395184556_n.png?_nc_cat=110&ccb=1-7&_nc_sid=5f2048&_nc_ohc=mYNcgBH-3DkQ7kNvgGCdmpw&_nc_ad=z-m&_nc_cid=0&_nc_ht=scontent.xx&oh=03_Q7cD1QFx_LNpfQrO1XEqH3Yj5_FJAWNq0l8RRSPWlm8S0AAzcw&oe=66807A84")

let stakii1 = db.get("staki1") || ' '
let stakii2 = db.get("staki2") || ' '
let stakii3 = db.get("staki3") || ' '
let stakii4 = db.get("staki4") || ' '
let stakii5 = db.get("staki5") || ' '
let stakii6 = db.get("staki6") || ' '
let stakii7 = db.get("staki7") || ' '
let stakii8 = db.get("staki8") || ' '
let stakii9 = db.get("staki9") || ' '
let stakii10 = db.get("staki10") || ' '
let stakii11 = db.get("staki11") || ' '
let stakii12 = db.get("staki12") || " "
let stakii13 = db.get("staki13") || " "
let stakii14 = db.get("staki14") ||   " "
let stakii15 = db.get("staki15") || " "
let stakii16 = db.get("staki16") || " "
let stakii17 = db.get("staki17") || " "
let stakii18 = db.get("staki18") || " "
message.channel.send("Tablo hazırlanıyor lütfen bekleyin.")
                            
let sstakii1 = db.get("staki1") 
let sstakii2 = db.get("staki2") 
let sstakii3 = db.get("staki3") 
let sstakii4 = db.get("staki4") 
let sstakii5 = db.get("staki5") 
let sstakii6 = db.get("staki6") 
let sstakii7 = db.get("staki7") 
let sstakii8 = db.get("staki8") 
let sstakii9 = db.get("staki9") 
let sstakii10 = db.get("staki10") 
let sstakii11 = db.get("staki11") 
let sstakii12 = db.get("staki12") 
let sstakii13 = db.get("staki13") 
let sstakii14 = db.get("staki14") 
let sstakii15 = db.get("staki15") 
let sstakii16 = db.get("staki16") 
let sstakii17 = db.get("staki17") 
let sstakii18 = db.get("staki18") 
    
let stakim1 = stakii1
let stakim2 = stakii2
let stakim3 = stakii3
let stakim4 = stakii4
let stakim5 = stakii5
let stakim6 = stakii6
let stakim7 = stakii7
let stakim8 = stakii8
let stakim9 = stakii9
let stakim10 = stakii10
let stakim11 = stakii11
let stakim12 = stakii12
let stakim13 = stakii13
let stakim14 = stakii14
let stakim15 = stakii15
let stakim16 = stakii16
let stakim17 = stakii17
let stakim18 = stakii18
  const background = await Canvas.loadImage(`https://scontent.xx.fbcdn.net/v/t1.15752-9/441436209_1858152441324408_7763326068395184556_n.png?_nc_cat=110&ccb=1-7&_nc_sid=5f2048&_nc_ohc=mYNcgBH-3DkQ7kNvgGCdmpw&_nc_ad=z-m&_nc_cid=0&_nc_ht=scontent.xx&oh=03_Q7cD1QFx_LNpfQrO1XEqH3Yj5_FJAWNq0l8RRSPWlm8S0AAzcw&oe=66807A84`);
  ctx.drawImage(background, 0, 0, canvas.width, canvas.height);

       const log1 = db.get(`${stakim1}`)
 const log2 = db.get(`${stakim2}`)
 const log3 = db.get(`${stakim3}`)
 const log4 = db.get(`${stakim4}`)
 const log5 = db.get(`${stakim5}`)
 const log6 = db.get(`${stakim6}`)
 const log7 = db.get(`${stakim7}`)
 const log8 = db.get(`${stakim8}`)
 const log9 = db.get(`${stakim9}`)
 const log10 = db.get(`${stakim10}`)
 const log11 = db.get(`${stakim11}`)
 const log12 = db.get(`${stakim12}`)
 const log13 = db.get(`${stakim13}`)
 const log14 = db.get(`${stakim14}`)
 const log15 = db.get(`${stakim15}`)
 const log16 = db.get(`${stakim16}`)
 const log17 = db.get(`${stakim17}`)
 const log18 = db.get(`${stakim18}`) 

 
 
 
 if (log1 == null) {var logo1 = 'https://scontent.xx.fbcdn.net/v/t1.15752-9/441436209_1858152441324408_7763326068395184556_n.png?_nc_cat=110&ccb=1-7&_nc_sid=5f2048&_nc_ohc=mYNcgBH-3DkQ7kNvgGCdmpw&_nc_ad=z-m&_nc_cid=0&_nc_ht=scontent.xx&oh=03_Q7cD1QFx_LNpfQrO1XEqH3Yj5_FJAWNq0l8RRSPWlm8S0AAzcw&oe=66807A84'} else {var logo1 = log1}
 if (log2 == null) {var logo2 = 'https://scontent.xx.fbcdn.net/v/t1.15752-9/441436209_1858152441324408_7763326068395184556_n.png?_nc_cat=110&ccb=1-7&_nc_sid=5f2048&_nc_ohc=mYNcgBH-3DkQ7kNvgGCdmpw&_nc_ad=z-m&_nc_cid=0&_nc_ht=scontent.xx&oh=03_Q7cD1QFx_LNpfQrO1XEqH3Yj5_FJAWNq0l8RRSPWlm8S0AAzcw&oe=66807A84'} else {var logo2 = log2}
 if (log3 == null) {var logo3 = 'https://scontent.xx.fbcdn.net/v/t1.15752-9/441436209_1858152441324408_7763326068395184556_n.png?_nc_cat=110&ccb=1-7&_nc_sid=5f2048&_nc_ohc=mYNcgBH-3DkQ7kNvgGCdmpw&_nc_ad=z-m&_nc_cid=0&_nc_ht=scontent.xx&oh=03_Q7cD1QFx_LNpfQrO1XEqH3Yj5_FJAWNq0l8RRSPWlm8S0AAzcw&oe=66807A84'} else {var logo3 = log3}
 if (log4 == null) {var logo4 = 'https://scontent.xx.fbcdn.net/v/t1.15752-9/441436209_1858152441324408_7763326068395184556_n.png?_nc_cat=110&ccb=1-7&_nc_sid=5f2048&_nc_ohc=mYNcgBH-3DkQ7kNvgGCdmpw&_nc_ad=z-m&_nc_cid=0&_nc_ht=scontent.xx&oh=03_Q7cD1QFx_LNpfQrO1XEqH3Yj5_FJAWNq0l8RRSPWlm8S0AAzcw&oe=66807A84'} else {var logo4 = log4}
 if (log5 == null) {var logo5 = 'https://scontent.xx.fbcdn.net/v/t1.15752-9/441436209_1858152441324408_7763326068395184556_n.png?_nc_cat=110&ccb=1-7&_nc_sid=5f2048&_nc_ohc=mYNcgBH-3DkQ7kNvgGCdmpw&_nc_ad=z-m&_nc_cid=0&_nc_ht=scontent.xx&oh=03_Q7cD1QFx_LNpfQrO1XEqH3Yj5_FJAWNq0l8RRSPWlm8S0AAzcw&oe=66807A84'} else {var logo5 = log5}
 if (log6 == null) {var logo6 = 'https://scontent.xx.fbcdn.net/v/t1.15752-9/441436209_1858152441324408_7763326068395184556_n.png?_nc_cat=110&ccb=1-7&_nc_sid=5f2048&_nc_ohc=mYNcgBH-3DkQ7kNvgGCdmpw&_nc_ad=z-m&_nc_cid=0&_nc_ht=scontent.xx&oh=03_Q7cD1QFx_LNpfQrO1XEqH3Yj5_FJAWNq0l8RRSPWlm8S0AAzcw&oe=66807A84'} else {var logo6 = log6}
 if (log7 == null) {var logo7 = 'https://scontent.xx.fbcdn.net/v/t1.15752-9/441436209_1858152441324408_7763326068395184556_n.png?_nc_cat=110&ccb=1-7&_nc_sid=5f2048&_nc_ohc=mYNcgBH-3DkQ7kNvgGCdmpw&_nc_ad=z-m&_nc_cid=0&_nc_ht=scontent.xx&oh=03_Q7cD1QFx_LNpfQrO1XEqH3Yj5_FJAWNq0l8RRSPWlm8S0AAzcw&oe=66807A84'} else {var logo7 = log7}
 if (log8 == null) {var logo8 = 'https://scontent.xx.fbcdn.net/v/t1.15752-9/441436209_1858152441324408_7763326068395184556_n.png?_nc_cat=110&ccb=1-7&_nc_sid=5f2048&_nc_ohc=mYNcgBH-3DkQ7kNvgGCdmpw&_nc_ad=z-m&_nc_cid=0&_nc_ht=scontent.xx&oh=03_Q7cD1QFx_LNpfQrO1XEqH3Yj5_FJAWNq0l8RRSPWlm8S0AAzcw&oe=66807A84'} else {var logo8 = log8}
 if (log9 == null) {var logo9 = 'https://scontent.xx.fbcdn.net/v/t1.15752-9/441436209_1858152441324408_7763326068395184556_n.png?_nc_cat=110&ccb=1-7&_nc_sid=5f2048&_nc_ohc=mYNcgBH-3DkQ7kNvgGCdmpw&_nc_ad=z-m&_nc_cid=0&_nc_ht=scontent.xx&oh=03_Q7cD1QFx_LNpfQrO1XEqH3Yj5_FJAWNq0l8RRSPWlm8S0AAzcw&oe=66807A84'} else {var logo9 = log9}
 if (log10 == null) {var logo10 = 'https://scontent.xx.fbcdn.net/v/t1.15752-9/441436209_1858152441324408_7763326068395184556_n.png?_nc_cat=110&ccb=1-7&_nc_sid=5f2048&_nc_ohc=mYNcgBH-3DkQ7kNvgGCdmpw&_nc_ad=z-m&_nc_cid=0&_nc_ht=scontent.xx&oh=03_Q7cD1QFx_LNpfQrO1XEqH3Yj5_FJAWNq0l8RRSPWlm8S0AAzcw&oe=66807A84'} else {var logo10 = log10}
 if (log11 == null) {var logo11 = 'https://scontent.xx.fbcdn.net/v/t1.15752-9/441436209_1858152441324408_7763326068395184556_n.png?_nc_cat=110&ccb=1-7&_nc_sid=5f2048&_nc_ohc=mYNcgBH-3DkQ7kNvgGCdmpw&_nc_ad=z-m&_nc_cid=0&_nc_ht=scontent.xx&oh=03_Q7cD1QFx_LNpfQrO1XEqH3Yj5_FJAWNq0l8RRSPWlm8S0AAzcw&oe=66807A84'} else {var logo11 = log11}
 if (log12 == null) {var logo12 = 'https://scontent.xx.fbcdn.net/v/t1.15752-9/441436209_1858152441324408_7763326068395184556_n.png?_nc_cat=110&ccb=1-7&_nc_sid=5f2048&_nc_ohc=mYNcgBH-3DkQ7kNvgGCdmpw&_nc_ad=z-m&_nc_cid=0&_nc_ht=scontent.xx&oh=03_Q7cD1QFx_LNpfQrO1XEqH3Yj5_FJAWNq0l8RRSPWlm8S0AAzcw&oe=66807A84'} else {var logo12 = log12}
 if (log13 == null) {var logo13 = 'https://scontent.xx.fbcdn.net/v/t1.15752-9/441436209_1858152441324408_7763326068395184556_n.png?_nc_cat=110&ccb=1-7&_nc_sid=5f2048&_nc_ohc=mYNcgBH-3DkQ7kNvgGCdmpw&_nc_ad=z-m&_nc_cid=0&_nc_ht=scontent.xx&oh=03_Q7cD1QFx_LNpfQrO1XEqH3Yj5_FJAWNq0l8RRSPWlm8S0AAzcw&oe=66807A84'} else {var logo13 = log13}
 if (log14 == null) {var logo14 = 'https://scontent.xx.fbcdn.net/v/t1.15752-9/441436209_1858152441324408_7763326068395184556_n.png?_nc_cat=110&ccb=1-7&_nc_sid=5f2048&_nc_ohc=mYNcgBH-3DkQ7kNvgGCdmpw&_nc_ad=z-m&_nc_cid=0&_nc_ht=scontent.xx&oh=03_Q7cD1QFx_LNpfQrO1XEqH3Yj5_FJAWNq0l8RRSPWlm8S0AAzcw&oe=66807A84'} else {var logo14 = log14}
 if (log15 == null) {var logo15 = 'https://scontent.xx.fbcdn.net/v/t1.15752-9/441436209_1858152441324408_7763326068395184556_n.png?_nc_cat=110&ccb=1-7&_nc_sid=5f2048&_nc_ohc=mYNcgBH-3DkQ7kNvgGCdmpw&_nc_ad=z-m&_nc_cid=0&_nc_ht=scontent.xx&oh=03_Q7cD1QFx_LNpfQrO1XEqH3Yj5_FJAWNq0l8RRSPWlm8S0AAzcw&oe=66807A84'} else {var logo15 = log15}
 if (log16 == null) {var logo16 = 'https://scontent.xx.fbcdn.net/v/t1.15752-9/441436209_1858152441324408_7763326068395184556_n.png?_nc_cat=110&ccb=1-7&_nc_sid=5f2048&_nc_ohc=mYNcgBH-3DkQ7kNvgGCdmpw&_nc_ad=z-m&_nc_cid=0&_nc_ht=scontent.xx&oh=03_Q7cD1QFx_LNpfQrO1XEqH3Yj5_FJAWNq0l8RRSPWlm8S0AAzcw&oe=66807A84'} else {var logo16 = log16}
 if (log17 == null) {var logo17 = 'https://scontent.xx.fbcdn.net/v/t1.15752-9/441436209_1858152441324408_7763326068395184556_n.png?_nc_cat=110&ccb=1-7&_nc_sid=5f2048&_nc_ohc=mYNcgBH-3DkQ7kNvgGCdmpw&_nc_ad=z-m&_nc_cid=0&_nc_ht=scontent.xx&oh=03_Q7cD1QFx_LNpfQrO1XEqH3Yj5_FJAWNq0l8RRSPWlm8S0AAzcw&oe=66807A84'} else {var logo17 = log17}
 if (log18 == null) {var logo18 = 'https://scontent.xx.fbcdn.net/v/t1.15752-9/441436209_1858152441324408_7763326068395184556_n.png?_nc_cat=110&ccb=1-7&_nc_sid=5f2048&_nc_ohc=mYNcgBH-3DkQ7kNvgGCdmpw&_nc_ad=z-m&_nc_cid=0&_nc_ht=scontent.xx&oh=03_Q7cD1QFx_LNpfQrO1XEqH3Yj5_FJAWNq0l8RRSPWlm8S0AAzcw&oe=66807A84'} else {var logo18 = log18}


  const logoo1 = await Canvas.loadImage(logo1);
  try {  ctx.drawImage(logoo1, 320, 266, 34, 34) } catch(e) { console.log(logoo1)}
  const logoo2 = await Canvas.loadImage(logo2);
  try {  ctx.drawImage(logoo2, 320, 306, 34, 34) } catch(e) {console.log(logoo2)}
  const logoo3 = await Canvas.loadImage(logo3);
  try {  ctx.drawImage(logoo3, 320, 345, 34, 34) } catch(e) {console.log(logoo3)}
   const logoo4 = await Canvas.loadImage(`${logo4}`);
  try {  ctx.drawImage(logoo4, 320, 385, 34, 34) } catch(e) {console.log(logoo4)}
  const logoo5 = await Canvas.loadImage(`${logo5}`);
  try {  ctx.drawImage(logoo5, 320, 425, 34, 34) } catch(e) {console.log(logoo5)}
  const logoo6 = await Canvas.loadImage(`${logo6}`);
  try {  ctx.drawImage(logoo6, 320, 465, 34, 34) } catch(e) {console.log(logoo6)}
  const logoo7 = await Canvas.loadImage(`${logo7}`);
  try {  ctx.drawImage(logoo7, 320, 505, 34, 34) } catch(e) {console.log(logoo7)}
  const logoo8 = await Canvas.loadImage(`${logo8}`);
  try {  ctx.drawImage(logoo8, 320, 545, 34, 34) } catch(e) {console.log(logoo8)}
  const logoo9 = await Canvas.loadImage(`${logo9}`);
  try {  ctx.drawImage(logoo9, 320, 585, 34, 34) } catch(e) {console.log(logoo9)}
  const logoo10 = await Canvas.loadImage(`${logo10}`);
  try {  ctx.drawImage(logoo10, 751, 266, 34, 34) } catch(e) {console.log(logoo10)}
  const logoo11 = await Canvas.loadImage(`${logo11}`);
  try {  ctx.drawImage(logoo11, 751, 306, 34, 34) } catch(e) {console.log(logoo11)}
  const logoo12 = await Canvas.loadImage(`${logo12}`);
  try {  ctx.drawImage(logoo12, 751, 345, 34, 34) } catch(e) {console.log(logoo12)}
  const logoo13 = await Canvas.loadImage(`${logo13}`);
  try {  ctx.drawImage(logoo13, 751, 385, 34, 34) } catch(e) {console.log(logoo13)}
  const logoo14 = await Canvas.loadImage(`${logo14}`);
  try {  ctx.drawImage(logoo14, 751, 425, 34, 34) } catch(e) {console.log(logoo14)}
  const logoo15 = await Canvas.loadImage(`${logo15}`); 
  try {  ctx.drawImage(logoo15, 751, 465, 34, 34) } catch(e) {console.log(logoo15)}
  const logoo16 = await Canvas.loadImage(`${logo16}`);
  try {  ctx.drawImage(logoo16, 751, 505, 34, 34) } catch(e) {console.log(logoo16)}
  const logoo17 = await Canvas.loadImage(`${logo17}`);
  try {  ctx.drawImage(logoo17, 751, 545, 34, 34) } catch(e) {console.log(logoo17)}
  const logoo18 = await Canvas.loadImage(`${logo18}`);
  try {  ctx.drawImage(logoo18, 751, 585, 34, 34) } catch(e) {console.log(logoo18)}
   
    
  ctx.fillStyle = "#fff";
  ctx.font = "25px American-Captain";
   // TAKIMLAR //
  ctx.fillText(`${stakim1}`, 363, 294);
  ctx.fillText(`${stakim2}`, 363, 334);
  ctx.fillText(`${stakim3}`, 363, 373);
  ctx.fillText(`${stakim4}`, 363, 413);
  ctx.fillText(`${stakim5}`, 363, 453);
  ctx.fillText(`${stakim6}`, 363, 493);
  ctx.fillText(`${stakim7}`, 363, 533);
  ctx.fillText(`${stakim8}`, 363, 573);
  ctx.fillText(`${stakim9}`, 363, 613);
  
  ctx.fillText(`${stakim10}`, 794, 294);
  ctx.fillText(`${stakim11}`, 794, 334);
  ctx.fillText(`${stakim12}`, 794, 373);
  ctx.fillText(`${stakim13}`, 794, 413);
  ctx.fillText(`${stakim14}`, 794, 453);
  ctx.fillText(`${stakim15}`, 794, 493);
  ctx.fillText(`${stakim16}`, 794, 533);
  ctx.fillText(`${stakim17}`, 794, 573);
  ctx.fillText(`${stakim18}`, 794, 613);
  // TAKIM SON //
  const attachment = new Discord.MessageAttachment(canvas.toBuffer(), "");
  message.channel.send(attachment);
 
     setTimeout(() => {
          message.channel.send("Slota yazılan takımları resulta da geçirmek ister misin?")
 message.channel.send("Eğer istiyorsanız **`evet`**. Eğer istemiyorsanız **`hayır`** yazın.")
        }, 1000);
  

const json = require("json-update");

  let uwu = false;
  while (!uwu) {
    const response = await message.channel.awaitMessages(neblm => neblm.author.id === message.author.id, { max: 1, time: 30000 });
    const choice = response.first().content || 'h'
    if (choice == 'hayır' || choice == 'h' || choice == 'Hayır' || choice == 'H') return message.channel.send('🚀 İşlem iptal edildi.')
    if (choice !== 'evet' && choice !== 'e' ) {
      message.channel.send('Lütfen sadece **evet (e)** veya **hayır (h)** ile cevap verin.')
    }
    if (choice == 'evet' || choice == 'e' || choice == 'Evet' || choice == 'E') uwu = true
  }
  if (uwu) {
    try {
       json.update("./cfg/config.json", {
        takim1: sstakii1,
        takim2: sstakii2,
        takim3: sstakii3,
        takim4: sstakii4,
        takim5: sstakii5,
        takim6: sstakii6,
        takim7: sstakii7,
        takim8: sstakii8,
        takim9: sstakii9,
        takim10: sstakii10,
        takim11: sstakii11,
        takim12: sstakii12,
        takim13: sstakii13,
        takim14: sstakii14,
        takim15: sstakii15,
        takim16: sstakii16,
        takim17: sstakii17,
        takim18: sstakii18,
        kp1bir: ``,
          kp2bir: ``,
          kp3bir: ``,
          kp4bir: ``,
          kp5bir: ``,
          kp6bir: ``,
          kp7bir: ``,
          kp8bir: ``,
          kp9bir: ``,
          kp10bir: ``,
          kp11bir: ``,
          kp12bir: ``,
          kp13bir: ``,
          kp14bir: ``,
          kp15bir: ``,
          kp16bir: ``,
          kp17bir: ``,
          kp18bir: ``,
          kp19bir: ``,
          kp20bir: ``,
          kp21bir: ``,
          kp22bir: ``,
          kp23bir: ``,
          kp24bir: ``,
          kp25bir: ``,
          kp1iki: ``,
          kp2iki: ``,
          kp3iki: ``,
          kp4iki: ``,
          kp5iki: ``,
          kp6iki: ``,
          kp7iki: ``,
          kp8iki: ``,
          kp9iki: ``,
          kp10iki: ``,
          kp11iki: ``,
          kp12iki: ``,
          kp13iki: ``,
          kp14iki: ``,
          kp15iki: ``,
          kp16iki: ``,
          kp17iki: ``,
          kp18iki: ``,
          kp19iki: ``,
          kp20iki: ``,
          kp21iki: ``,
          kp22iki: ``,
          kp23iki: ``,
          kp24iki: ``,
          kp25iki: ``,
          kp1üç: ``,
          kp2üç: ``,
          kp3üç: ``,
          kp4üç: ``,
          kp5üç: ``,
          kp6üç: ``,
          kp7üç: ``,
          kp8üç: ``,
          kp9üç: ``,
          kp10üç: ``,
          kp11üç: ``,
          kp12üç: ``,
          kp13üç: ``,
          kp14üç: ``,
          kp15üç: ``,
          kp16üç: ``,
          kp17üç: ``,
          kp18üç: ``,
          kp19üç: ``,
          kp20üç: ``,
          kp21üç: ``,
          kp22üç: ``,
          kp23üç: ``,
          kp24üç: ``,
          kp25üç: ``,
          kp1dört: ``,
          kp2dört: ``,
          kp3dört: ``,
          kp4dört: ``,
          kp5dört: ``,
          kp6dört: ``,
          kp7dört: ``,
          kp8dört: ``,
          kp9dört: ``,
          kp10dört: ``,
          kp11dört: ``,
          kp12dört: ``,
          kp13dört: ``,
          kp14dört: ``,
          kp15dört: ``,
          kp16dört: ``,
          kp17dört: ``,
          kp18dört: ``,
          kp19dört: ``,
          kp20dört: ``,
          kp21dört: ``,
          kp22dört: ``,
          kp23dört: ``,
          kp24dört: ``,
          kp25dört: ``,
                      kp1beş: ``,
          kp2beş: ``,
          kp3beş: ``,
          kp4beş: ``,
          kp5beş: ``,
          kp6beş: ``,
          kp7beş: ``,
          kp8beş: ``,
          kp9beş: ``,
          kp10beş: ``,
          kp11beş: ``,
          kp12beş: ``,
          kp13beş: ``,
          kp14beş: ``,
          kp15beş: ``,
          kp16beş: ``,
          kp17beş: ``,
          kp18beş: ``,
          kp19beş: ``,
          kp20beş: ``,
          kp21beş: ``,
          kp22beş: ``,
          kp23beş: ``,
          kp24beş: ``,
          kp25beş: ``,
          sp1bir: ``,
          sp2bir: ``,
          sp3bir: ``,
          sp4bir: ``,
          sp5bir: ``,
          sp6bir: ``,
          sp7bir: ``,
          sp8bir: ``,
          sp9bir: ``,
          sp10bir: ``,
          sp11bir: ``,
          sp12bir: ``,
          sp13bir: ``,
          sp14bir: ``,
          sp15bir: ``,
          sp16bir: ``,
          sp17bir: ``,
          sp18bir: ``,
          sp19bir: ``,
          sp20bir: ``,
          sp21bir: ``,
          sp22bir: ``,
          sp23bir: ``,
          sp24bir: ``,
          sp25bir: ``,
          sp1iki: ``,
          sp2iki: ``,
          sp3iki: ``,
          sp4iki: ``,
          sp5iki: ``,
          sp6iki: ``,
          sp7iki: ``,
          sp8iki: ``,
          sp9iki: ``,
          sp10iki: ``,
          sp11iki: ``,
          sp12iki: ``,
          sp13iki: ``,
          sp14iki: ``,
          sp15iki: ``,
          sp16iki: ``,
          sp17iki: ``,
          sp18iki: ``,
          sp19iki: ``,
          sp20iki: ``,
          sp21iki: ``,
          sp22iki: ``,
          sp23iki: ``,
          sp24iki: ``,
          sp25iki: ``,
          sp1üç: ``,
          sp2üç: ``,
          sp3üç: ``,
          sp4üç: ``,
          sp5üç: ``,
          sp6üç: ``,
          sp7üç: ``,
          sp8üç: ``,
          sp9üç: ``,
          sp10üç: ``,
          sp11üç: ``,
          sp12üç: ``,
          sp13üç: ``,
          sp14üç: ``,
          sp15üç: ``,
          sp16üç: ``,
          sp17üç: ``,
          sp18üç: ``,
          sp19üç: ``,
          sp20üç: ``,
          sp21üç: ``,
          sp22üç: ``,
          sp23üç: ``,
          sp24üç: ``,
          sp25üç: ``,
          sp1dört: ``,
          sp2dört: ``,
          sp3dört: ``,
          sp4dört: ``,
          sp5dört: ``,
          sp6dört: ``,
          sp7dört: ``,
          sp8dört: ``,
          sp9dört: ``,
          sp10dört: ``,
          sp11dört: ``,
          sp12dört: ``,
          sp13dört: ``,
          sp14dört: ``,
          sp15dört: ``,
          sp16dört: ``,
          sp17dört: ``,
          sp18dört: ``,
          sp19dört: ``,
          sp20dört: ``,
          sp21dört: ``,
          sp22dört: ``,
          sp23dört: ``,
          sp24dört: ``,
          sp25dört: ``,
                sp1beş: ``,
          sp2beş: ``,
          sp3beş: ``,
          sp4beş: ``,
          sp5beş: ``,
          sp6beş: ``,
          sp7beş: ``,
          sp8beş: ``,
          sp9beş: ``,
          sp10beş: ``,
          sp11beş: ``,
          sp12beş: ``,
          sp13beş: ``,
          sp14beş: ``,
          sp15beş: ``,
          sp16beş: ``,
          sp17beş: ``,
          sp18beş: ``,
          sp19beş: ``,
          sp20beş: ``,
          sp21beş: ``,
          sp22beş: ``,
          sp23beş: ``,
          sp24beş: ``,
          sp25beş: ``
        
      })
  message.channel.send(":white_check_mark: Başarıyla resulta geçirildi.")
      //const activity = activitys[Math.floor(Math.random() * activitys.length)];
      } catch(e) {
        message.channel.send(':warning: Bir hata var!')
      }
  }
  




}