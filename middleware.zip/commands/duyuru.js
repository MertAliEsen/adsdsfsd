const Discord = require("discord.js");
const ayarlar = require('../ayarlar.json');
let prefix = ayarlar.prefix
let emoji = ayarlar.emoji
module.exports.run = async (client, message, args) => {
const embed = new Discord.MessageEmbed()
.setTitle(`__${client.user.username}__ Duyuru Komutları`)
.addField(`**${emoji} ${prefix}mesaj1 "Text"**`,"Logosuz embed atar.")
.addField(`**${emoji} ${prefix}mesaj2 "Text"**`,"Logolu embed atar.")
.addField(`**${emoji} ${prefix}yaz "Text"**`,"Embedsiz yazı yazar.")
.addField(`**${emoji} ${prefix}foto-mesaj "#Kanal" "Text" (+ Ekte Görsel)**`,"Seçilen kanala eklenen görseli ve texti embed olarak atar.")
.addField(`**${emoji} ${prefix}dm @kullanıcı "Gönderilecek mesaj"**`,"Belirlediğiniz kullanıcıya bot ile özelden mesaj gönderir.")
.setThumbnail(`${ayarlar.foto}`)
.setFooter(`${client.user.username}`)
.setColor(`${ayarlar.renk}`)
message.channel.send(embed);
};
