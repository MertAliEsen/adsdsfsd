const Discord = require('discord.js')
const db = require('quick.db')
const ayarlar = require('../ayarlar.json')
 
exports.run = async(client, message, args) => {

let prefix = ayarlar.prefix
  
if (!args[0]){
  message.channel.send(`${ayarlar.prefix}rol-koruma **kapat/aç** yazmalısın.`)
}
  if (args[0] === 'aç') {
    
    db.set(`rol_${message.guild.id}`, "açık")
  
    return message.channel.send(`Rol koruma aktif.`)
  }
   if (args[0] === 'kapat') {
    
    db.set(`rol_${message.guild.id}`, "kapalı")
 
    return message.channel.send(`Rol koruma kapatıldı.`)
  }
};
