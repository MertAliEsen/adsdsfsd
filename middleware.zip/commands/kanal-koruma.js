const Discord = require('discord.js')
const db = require('quick.db')
const ayarlar = require('../ayarlar.json')
 
exports.run = async(client, message, args) => {

let prefix = ayarlar.prefix
  
if (!args[0]){
  message.channel.send(`${ayarlar.prefix}kanal-koruma **kapat/aç** yazmalısın.`)
}
  if (args[0] === 'aç') {
    
    db.set(`kanal_${message.guild.id}`, "açık")
  
    return message.channel.send(`Kanal koruma aktif.`)
  }
   if (args[0] === 'kapat') {
    
    db.set(`kanal_${message.guild.id}`, "kapalı")
 
    return message.channel.send(`Kanal koruma kapatıldı.`)
  }
};
