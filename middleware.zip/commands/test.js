






const Discord = require("discord.js");
const ayarlar = require('../ayarlar.json');
let prefix = ayarlar.prefix
let emoji = ayarlar.emoji
let foto = ayarlar.foto

module.exports.run = async (client, message, args) => {
message.channel.send(`**__Fiyat Listesi:__**
ㅤ
**・Scrim: 300₺**
**・Moderasyon: 150₺**
**・Guard: 150₺**
**・Oto Rol: 50₺**
**・Destek (Ticket): 50₺**

Toplu alımlarda indirim uygulanmaktadır. 
İstenen tüm özellikler tamamen tek bota eklenir. Her işi tek bot yapar.

**__Botun tüm özelliklerini ver kullanılışını görmek için:__**
<#1221211634526195772>

**__Bot satın almak için:__**
<#1220545694016864336>`)

};