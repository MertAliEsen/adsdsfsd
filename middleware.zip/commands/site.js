const ayarlar = require('../ayarlar.json');
const Discord = require('discord.js');
exports.run = (client, message, args) => {
 if(!message.member.roles.cache.has(`${ayarlar.rol}`)) return message.channel.send('Yetkin yok')
      
 let user = message.author

//  if (message.mentions.users.cache.size < 1) return message.reply('Kime Mesaj Göndereceğim yaz veya etiketle.').catch(console.error);


   user.send(`Sitemizin linki!\nhttps://www.github.com`);
  message.reply('Özelden linki gönderdim.')
};