  const Discord = require("discord.js");
const ayarlar = require('../ayarlar.json');
let prefix = ayarlar.prefix
let emoji = ayarlar.emoji
let foto = ayarlar.foto

module.exports.run = async (client, message, args) => {

const embed = new Discord.MessageEmbed()
.setTitle(`__${client.user.username}__ Bot komutları.`)
.addField(`**${emoji} ${prefix}tablo**`,"Çıkartabileceğiniz tablolar yardım menüsü.")
.addField(`**${emoji} ${prefix}logo**`,"Logo komutları yardım menüsü.")
//.addField(`**${emoji} ${prefix}duyuru**`,"Duyuru komutları yardım menüsü.")
//.addField(`**${emoji} ${prefix}moderasyon**`,"Moderasyon komutları yardım menüsü.")
.setThumbnail(`${ayarlar.foto}`)
.setFooter(`${client.user.username}`)
.setColor(`${ayarlar.renk}`)
message.channel.send(embed);
};