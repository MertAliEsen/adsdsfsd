const Discord = require('discord.js');
const ayarlar = require('../ayarlar.json');

exports.run = async (client, message, args) => {
                        if(!message.member.roles.cache.has(`${ayarlar.rol}`)) return message.channel.send('Yetkin yok')

  const logo =  message.attachments.first().url || "https://scontent.xx.fbcdn.net/v/t1.15752-9/441436209_1858152441324408_7763326068395184556_n.png?_nc_cat=110&ccb=1-7&_nc_sid=5f2048&_nc_ohc=mYNcgBH-3DkQ7kNvgGCdmpw&_nc_ad=z-m&_nc_cid=0&_nc_ht=scontent.xx&oh=03_Q7cD1QFx_LNpfQrO1XEqH3Yj5_FJAWNq0l8RRSPWlm8S0AAzcw&oe=66807A84"
      const kanal =  message.mentions.channels.first()
  let mesaj1 = args.slice(1).join(' ');
if (mesaj1.length < 1) return message.reply(commands/yaz.js);

     let k = await kanal.id;

const embed1 = new Discord.MessageEmbed()
.setColor(`${ayarlar.renk}`)
.setImage(logo)
.setDescription(`${mesaj1}`)
    client.channels.cache.get(`${k}`).send(embed1)

  message.channel.send(`Başarıyla gönderildi.`)
};

