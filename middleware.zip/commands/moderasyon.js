const Discord = require("discord.js");
const ayarlar = require('../ayarlar.json');
let prefix = ayarlar.prefix
let emoji = ayarlar.emoji
let foto = ayarlar.foto

module.exports.run = async (client, message, args) => {

  const embed = new Discord.MessageEmbed()

.setTitle(`__${client.user.username}__ Moderasyon komutları`)

.addField(`**${ayarlar.emoji} ${ayarlar.prefix}kanal-koruma aç/kapat**`, `Kanal koruma açıp kapatır.`)
.addField(`**${ayarlar.emoji} ${ayarlar.prefix}rol-koruma aç/kapat**`, `Rol koruma açıp kapatır.`)
.addField(`**${ayarlar.emoji} ${ayarlar.prefix}küfür-engel aç/kapat**`, `Küfür engeli açıp kapatır.`)
.addField(`**${ayarlar.emoji} ${ayarlar.prefix}reklam-engel aç/kapat**` , `Reklam engeli açıp kapatır.`)
.addField(`**${ayarlar.emoji} ${ayarlar.prefix}modlog aç/kapat #kanal**` , `Modlog açıp kapatır.`)

.setThumbnail(`${ayarlar.foto}`)
.setFooter(`${client.user.username}`)
.setColor(`${ayarlar.renk}`)
message.channel.send(embed)
};