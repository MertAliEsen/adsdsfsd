const Discord = require('discord.js');
const db = require('quick.db');
const ayarlar = require('../ayarlar.json');

exports.run = async (client, message, args) => {
  if(!message.member.roles.cache.has(`${ayarlar.rol}`)) return message.channel.send('Yetkin yok')
  
  if (!args[0]){
    message.channel.send(`${ayarlar.prefix}küfür-engel **kapat/aç** yazmalısın.`)
  }
  if (args[0] === 'aç'){
    message.channel.send("Küfür engel aktif.")
    
    db.set(`küfür_${message.guild.id}`, "açık")
  }
  if (args[0] === 'kapat'){
    message.channel.send('Küfür engel kapatıldı.')
    
    db.set(`küfür_${message.guild.id}`, "kapalı")
  }
}
