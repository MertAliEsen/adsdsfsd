const Discord = require('discord.js');
const db = require('quick.db');
const ayarlar = require('../ayarlar.json');

exports.run = async(client, message, args) => {


  if(!message.member.roles.cache.has(`${ayarlar.rol}`)) return message.channel.send('Yetkin yok')
  if (!args[0]){
    message.channel.send(`${ayarlar.prefix}reklam-engel **kapat/aç** yazmalısın.`)
  }
  if (args [0] == 'aç') {
    db.set(`reklam_${message.guild.id}`, 'açık')
 
    return message.channel.send('Reklam engel aktif.')

  }
  
  if (args [0] == 'kapat') {
      
    db.set(`reklam_${message.guild.id}`,'kapalı')

    return message.channel.send('Reklam engel kapatıldı.')
  }
  
};