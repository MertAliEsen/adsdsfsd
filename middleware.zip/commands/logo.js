const Discord = require("discord.js");
const ayarlar = require('../ayarlar.json');
let prefix = ayarlar.prefix
let emoji = ayarlar.emoji

module.exports.run = async (client, message, args) => {

const embed = new Discord.MessageEmbed()
.setTitle(`__${client.user.username}__ Logo komutları`)
//.addField(`**${emoji} ${prefix}logo-yükle "takım adı" ||+ ekte fotoğraf||**`,"Logo yüklemeye yarar")
.addField(`**${emoji} ${prefix}logo-sil "takım adı"**`,"Yüklediğiniz logoları siler.")
.addField(`**${emoji} ${prefix}logo-kontrol "takım adı"**`,"Takımın logosu olup olmadığını kontrol eder.")
.setThumbnail(`${ayarlar.foto}`)
.setFooter(`${client.user.username}`)
.setColor(`${ayarlar.renk}`)
message.channel.send(embed);
};
