const Discord = require('discord.js');
const db = require('quick.db');
const ayarlar = require('../ayarlar.json');

exports.run = async (client, message, args) => {

  
  let name = args.slice(0).join(' ');
if (name.length < 1) return message.reply('Lütfen bir takım yazın.');


db.delete(name)
message.react(":white_check_mark:");
message.channel.send(`**${name}** isimli logo başarıyla veri merkezinden kaldırıldı.`)
  message.delete
};

