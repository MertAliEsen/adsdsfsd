const Discord = require('discord.js');
const db = require('quick.db');
const ayarlar = require('../ayarlar.json');

exports.run = async (client, message, args) => {

   
  let aaa = args.slice(0).join(' ');
if (aaa.length < 1) return message.reply('Lütfen bir takım yazın.');
  let aaaa = aaa.toUpperCase();
   var logo = db.get(aaaa)
      

 
//.setImage(attachment)
if (!logo){
  message.channel.send("**Bu takımın logosu bulunmamaktadır.**")
} else {




try { 
  const attachment = new Discord.MessageAttachment(logo)
  const embed1 = new Discord.MessageEmbed()
  .setColor(ayarlar.renk)
  .attachFiles(attachment)
  .setTitle(`__**${aaaa}**__ isimli takımının logosu yukarıdadır.`)
  
  message.channel.send(embed1)
} catch(err) {console.log(aaaa + `adlı logoda hata.`), message.channel.send("**Bu takımın logosu bulunmamaktadır.**")}

console.log(aaaa + `  En son bu isimli logo sorgulandı. Eğer hata alındıysa konsolda gözükür.`)
message.channel.send("||Eğer hiç bir fotoğraf gelmediyse yüklenen logoda bir sorun vardır. Logoyu tekrar yüklemeyi deneyebilirsiniz.||")



}
};

