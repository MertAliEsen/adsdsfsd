const Discord = require("discord.js");
const ayarlar = require('../ayarlar.json');
let prefix = ayarlar.prefix
let emoji = ayarlar.emoji
let foto = ayarlar.foto
module.exports.run = async (client, message, args) => {
const embed = new Discord.MessageEmbed()
.setTitle(`__${client.user.username}__ Tablolar.`)
.addField(`**${emoji} ${prefix}result**`,"Result tablosu.")
.addField(`**${emoji} ${prefix}slot**`,"Slot tablosu.")
//.addField(`**${emoji} ${prefix}takım-i "takım adı"**`,"Belirtilen Takımın Bu Sunucudaki İstatistikleri Görünür (Bot ile yapılan tablolarda geçerlidir)")
.setThumbnail(`${ayarlar.foto}`)
.setFooter(`${client.user.username}`)
.setColor(`${ayarlar.renk}`)
message.channel.send(embed);
};
