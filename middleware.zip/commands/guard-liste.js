const Discord = require('discord.js')
const db = require('quick.db')
const ayarlar = require('../ayarlar.json')
 
exports.run = async(client, message, args) => {

let prefix = ayarlar.prefix
let kanal = db.fetch(`kanal_${message.guild.id}`)
let rol = db.get(`rol_${message.guild.id}`)
let küfür = db.fetch(`küfür_${message.guild.id}`)
let reklam = db.fetch(`reklam_${message.guild.id}`)

if (kanal == "açık" ) {var kanalkoruma = ":white_check_mark:"} else {var kanalkoruma = ":x:"}
if (rol == "açık" ) {var rolkoruma = ":white_check_mark:"} else {var rolkoruma = ":x:"}
if (küfür == "açık" ) {var küfürkoruma = ":white_check_mark:"} else {var küfürkoruma = ":x:"}
if (reklam == "açık" ) {var reklamkoruma = ":white_check_mark:"} else {var reklamkoruma = ":x:"}
const embed = new Discord.MessageEmbed()
.setTitle(`__${client.user.username}__ Bot komutları.`)
.setDescription(`Rol koruma: ${rolkoruma}\nKanal koruma: ${kanalkoruma}\nKüfür engel: ${küfürkoruma}\nReklam engel: ${reklamkoruma}`)
.setThumbnail(`${ayarlar.foto}`)
.setFooter(`${client.user.username}`)
.setColor(`${ayarlar.renk}`)
message.channel.send(embed);


};